package com.example.autocombat;

/**
 * Separate Auto Cobweb module.
 *
 * Planned behavior:
 * 1. Detect a confirmed shield-disable event on a valid target.
 * 2. Check that a cobweb is available and placement is valid.
 * 3. Aim/place only when the player has a clear, valid placement.
 * 4. Restore the prior view/aim state.
 *
 * This class is a scaffold; the automated combat behavior is not implemented yet.
 */
public final class AutoCobwebModule {
    private AutoCobwebModule() {}

    public static boolean isEnabled() {
        return AutoCombatClient.isAutoCobwebEnabled();
    }
}
