package com.example.autocombat;

/**
 * Separate Mace Slam module. It is independent from Auto Cobweb.
 *
 * This class is a scaffold; target selection, fall-distance checks,
 * aiming, and attack timing still need to be implemented and tested.
 */
public final class MaceSlamModule {
    private MaceSlamModule() {}

    public static boolean isEnabled() {
        return AutoCombatClient.isMaceSlamEnabled();
    }
}
