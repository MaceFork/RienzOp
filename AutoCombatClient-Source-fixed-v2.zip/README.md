# Auto Combat Client — source starter

Target: Minecraft Java 1.21.11, Fabric, Java 21.

## Current state
- F6 toggles the Auto Cobweb module state.
- F7 toggles the Mace Slam module state.
- The two module states are independent and display an on-screen status message.
- **This is source code, not a compiled JAR.** The automated cobweb placement, shield-disable detection, aim restoration, mace target/aiming and smash timing are not implemented in this starter.

## Build
Use a Java 21 development environment with Gradle. From this folder run:

```sh
gradle build
```

The built mod JAR should appear in `build/libs/`. Use the JAR without `-sources` in its name.

## Dependencies
- Minecraft 1.21.11
- Fabric Loader 0.18.0 or newer compatible with the launcher
- Fabric API 0.141.1+1.21.11
- Java 21

If the current Fabric Loom snapshot is unavailable or has changed, select a stable Loom version from the official Fabric developer page and update `build.gradle`.

## Mojo Launcher note
This is a client-side mod project. A successful build does not guarantee it works in every Android launcher; test it with a backup of your instance and check the game log if it fails.
