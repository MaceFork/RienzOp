package com.example.autocombat;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import com.mojang.blaze3d.platform.InputConstants;
import org.lwjgl.glfw.GLFW;

public final class AutoCombatClient implements ClientModInitializer {
    private static KeyMapping autoCobwebKey;
    private static KeyMapping maceSlamKey;
    private static boolean autoCobwebEnabled = false;
    private static boolean maceSlamEnabled = false;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category category = KeyMapping.Category.register(
                ResourceLocation.fromNamespaceAndPath("autocombatclient", "combat"));

        autoCobwebKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.autocombatclient.auto_cobweb",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_F6,
                category));

        maceSlamKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.autocombatclient.mace_slam",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_F7,
                category));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (autoCobwebKey.consumeClick()) {
                autoCobwebEnabled = !autoCobwebEnabled;
                notifyPlayer(client, "Auto Cobweb: " + (autoCobwebEnabled ? "ON" : "OFF"));
            }
            while (maceSlamKey.consumeClick()) {
                maceSlamEnabled = !maceSlamEnabled;
                notifyPlayer(client, "Mace Slam: " + (maceSlamEnabled ? "ON" : "OFF"));
            }

            // Feature implementation intentionally left as a safe starter scaffold.
            // Auto Cobweb behavior belongs in AutoCobwebModule; Mace Slam belongs
            // in MaceSlamModule. They are independent toggles.
        });
    }

    private static void notifyPlayer(Minecraft client, String message) {
        if (client.player != null) {
            client.player.displayClientMessage(
                    Component.literal("[AutoCombat] " + message), true);
        }
    }

    public static boolean isAutoCobwebEnabled() {
        return autoCobwebEnabled;
    }

    public static boolean isMaceSlamEnabled() {
        return maceSlamEnabled;
    }
}
